import React from 'react'

const HodDashboard = () => {
  return (

    <div>
      <h1>Welcome HOD</h1>
    </div>
  )
}

export default HodDashboard;