import React from 'react'

const MentorDashboard = () => {
  return (
    <div>MentorDashboard</div>
  )
}

export default MentorDashboard