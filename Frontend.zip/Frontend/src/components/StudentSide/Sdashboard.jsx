import Navbars from "./Navbars";


const Sdashboard = () => {
  return (
    <div>
      <Navbars />
    </div>
  );
};

export default Sdashboard;
